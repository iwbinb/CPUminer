#!/bin/sh
while [ 1 ]; do
./cpuminer-sse2 -a yespowerr32 -o stratum+tcp://pool.rplant.xyz:3350 -u VY5h5qArRPh93NwyiYEFjCk6P2FyzHAgfR.01
done
