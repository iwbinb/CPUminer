#!/bin/sh
while [ 1 ]; do
./cpuminer-sse2 -a yespower -o stratum+tcp://pool.rplant.xyz:3335 -u WALLET_ADDRESS.WORKER_NAME
done
