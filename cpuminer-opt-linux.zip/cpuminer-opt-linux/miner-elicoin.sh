#!/bin/sh
while [ 1 ]; do
./cpuminer-sse2 -a yespowerr16 -o stratum+tcp://pool.rplant.xyz:3337 -u WALLET.WORKER_NAME
done
